from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# In-memory phonebook (temporary storage)
phonebook = []

@app.route('/')
def index():
    return render_template('index.html', phonebook=phonebook)

@app.route('/add', methods=['POST'])
def add_contact():
    name = request.form['name']
    phone = request.form['phone']
    email = request.form['email']
    phonebook.append({'name': name, 'phone': phone, 'email': email})
    return redirect(url_for('index'))

@app.route('/search', methods=['GET', 'POST'])
def search():
    results = []
    if request.method == 'POST':
        query = request.form['query'].lower()
        results = [c for c in phonebook if query in c['name'].lower() or query in c['phone']]
    return render_template('search.html', results=results)

if __name__ == '__main__':
    app.run(debug=True)
